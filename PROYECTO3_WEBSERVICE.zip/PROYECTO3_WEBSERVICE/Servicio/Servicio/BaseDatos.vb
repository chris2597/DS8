﻿Imports MySql.Data.MySqlClient
Public Class BaseDatos
    Dim connectionString As String
    Dim connection As MySqlConnection
    Dim command As MySqlCommand
    Dim sql As String
    Dim sqlReader As MySqlDataReader


    Public Sub New()
        connectionString = "Data source=localhost; Database=Inventario; User ID=root;password=12345"
    End Sub

    'CONEXION A LA BASE DE DATOS
    Public Sub OpenBD()
        Try
            connection = New MySqlConnection(connectionString)
            connection.Open()
        Catch ex As Exception
            MsgBox("error abriendo base de datos" & ex.ToString())
        End Try
    End Sub

    Public Sub executeReader(sql As String)
        Try
            OpenBD()
            command = New MySqlCommand(sql, connection)
            sqlReader = command.ExecuteReader()
        Catch ex As Exception
            MsgBox("error leyendo" & ex.ToString())
        End Try
    End Sub

    Public Function Read()
        Return sqlReader.Read()
    End Function

    Public Function Item(campo As String) As String
        Return sqlReader.Item(campo)
    End Function

    Public Sub executeNonQuery(sql As String)
        Try
            OpenBD()
            command = New MySqlCommand(sql, connection)
            command.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox("error executeNonQuery " + ex.ToString())
        End Try
    End Sub

    Public Sub CloseBD()
        connection.Close()
    End Sub

End Class
