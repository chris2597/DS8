﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel


' Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class Producto
    Inherits System.Web.Services.WebService

    ' metodo que devuleve informacion del producto
    <WebMethod()>
    Public Function Feature(codProduct As String) As inventarioProductos
        Dim bd As BaseDatos = New BaseDatos()
        Dim prod As inventarioProductos = New inventarioProductos()
        Dim consultSql As String
        consultSql = "select * from Producto where cod_producto='" + codProduct + "'"
        bd.executeReader(consultSql)
        If bd.Read() Then
            prod.Description = bd.Item("descripcion")
            prod.CantExistence = bd.Item("cant_existente")
            prod.SalePrice = bd.Item("precio_venta")
        End If
        bd.CloseBD()
        Return prod
    End Function


End Class