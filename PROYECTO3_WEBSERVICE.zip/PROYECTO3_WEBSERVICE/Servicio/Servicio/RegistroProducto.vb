﻿Public Class inventarioProductos

    Dim _codProduct As String
    Dim _description As String
    Dim _cantExistence As Integer
    Dim _cantReOrden As Integer
    Dim _salePrice As Decimal
    Dim _cantPedir As Decimal

    Public Property CodProduct() As String
        Get
            Return _codProduct
        End Get

        Set(value As String)
            _codProduct = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return _description
        End Get

        Set(value As String)
            _description = value
        End Set
    End Property

    Public Property CantExistence() As Integer
        Get
            Return _cantExistence
        End Get
        Set(value As Integer)
            _cantExistence = value
        End Set
    End Property

    Public Property CantReOrden() As Integer
        Get
            Return _cantReOrden
        End Get
        Set(value As Integer)
            _cantReOrden = value
        End Set
    End Property

    Public Property SalePrice() As Decimal
        Get
            Return _salePrice
        End Get
        Set(value As Decimal)
            _salePrice = value
        End Set
    End Property

    Public Property CantPedir() As Decimal
        Get
            Return _cantPedir
        End Get
        Set(value As Decimal)
            _cantPedir = value
        End Set
    End Property


End Class