﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

' Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class WebService2
    Inherits System.Web.Services.WebService
    Dim bd As BaseDatos = New BaseDatos()
    Dim product As inventarioProductos = New inventarioProductos()
    Dim consultSql As String

    <WebMethod()>
    Public Function PointReorder(codProducto As String) As inventarioProductos

        consultSql = "select * from Producto where cod_producto='" + codProducto + "' and punto_reorden > cant_existente"
        bd.executeReader(consultSql)
        If bd.Read() Then
            product.Description = bd.Item("descripcion")
            product.CantExistence = bd.Item("cant_existente")
            product.CantReOrden = bd.Item("punto_reorden")
        End If
        bd.CloseBD()
        Return product
    End Function

    <WebMethod()>
    Public Function CantPedir(codProducto As String) As inventarioProductos

        consultSql = "select power(((cant_existente / punto_reorden) * 30),3) as cant_pedir from Producto where cod_producto = '" + codProducto + "' and cant_existente < punto_reorden"
        bd.executeReader(consultSql)
        If bd.Read() Then
            product.CantPedir = bd.Item("cant_pedir")
        End If
        bd.CloseBD()
        Return product
    End Function
End Class